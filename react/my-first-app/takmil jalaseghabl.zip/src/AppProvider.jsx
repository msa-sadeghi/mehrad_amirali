import { createContext, useState } from "react";


export const AppContext = createContext();
export function AppProvider({children}){
    const [user, setUser] = useState({name:'sara'});
    const [theme, setTheme] = useState('light');
    const [notifications, setNotifications] = useState([]);

    const value = {
        user, setUser,
        theme, setTheme,
        notifications, setNotifications
    }

    return(
        <AppContext.Provider value = {value}>
            {children}
        </AppContext.Provider>
    )
}