import { NotificationPanel } from "./components/NotificationPanel";
import { ThemeSwitcher } from "./components/ThemeSwitcher";
import { UserProfile } from "./components/UserProfile";
import { NotificationProvider } from "./NotificationContext";
import { ThemeProvider } from "./ThemeContext";
import { UserProvider } from "./UserContext";
NotificationProvider


function App(){
  return (
    
      <div>
        <UserProvider>
          <UserProfile/>
        </UserProvider>
        <ThemeProvider>

          <ThemeSwitcher/>
        </ThemeProvider>
        <NotificationProvider>

          <NotificationPanel/>
        </NotificationProvider>
       
      </div>
    
  )

}

export default App;