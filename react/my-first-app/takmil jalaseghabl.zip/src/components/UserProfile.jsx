import { useContext } from "react"
import { UserContext } from "../UserContext"


export function UserProfile(){
    const {user} = useContext(UserContext)
  
    console.log("user component rendered.")
    return <div>{user.name}</div>
}