import { useContext } from "react"
import { ThemeContext } from "../ThemeContext"

export function ThemeSwitcher(){
    const {theme, setTheme} = useContext(ThemeContext)
    console.log("theme component rendered.")
    return(
        <button
        onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
        >current: {theme}</button>
    )
}