import { useContext } from "react"
import { NotificationContext } from "../NotificationContext"

export function NotificationPanel(){
    const {notifications , setNotifications} = useContext(NotificationContext)
    console.log("notification component rendered.")
    return(
        <button
        onClick={() => setNotifications([...notifications, "new message"])}
        >Notifications({notifications.length})</button>
    )
}